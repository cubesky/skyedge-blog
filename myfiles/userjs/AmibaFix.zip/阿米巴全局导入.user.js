// ==UserScript==
// @name         阿米巴全局导入
// @version      0.1
// @description  向阿米巴装载全局资源
// @author       CubeSky
// @match        http://amiba.icesimba.com:8200/client/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    var blob = new Blob([`
button {
font-family: Arial;
color: #ffffff;
background: #3498db;
border: none;
text-decoration: none;
}

button:hover {
background: #3cb0fd;
text-decoration: none;
}

textarea {
  color: #000000 !important;
}

.gray-img {
  -webkit-animation: filter-animation 5s infinite linear;
  animation: filter-animation 5s infinite linear;
}

.gray-img-b {
  -webkit-filter: blur(10px) saturate(300%) sepia(20%);
  -moz-filter: blur(10px) saturate(300%) sepia(20%);
  -ms-filter: blur(10px) saturate(300%) sepia(20%);
  -o-filter: blur(10px) saturate(300%) sepia(20%);
  filter: blur(10px) saturate(300%) sepia(20%);
  filter: blur
}

@-webkit-keyframes filter-animation {
  0% {
    -webkit-filter: hue-rotate(0deg);
  }

  50% {
    -webkit-filter: hue-rotate(360deg);
  }

  100% {
    -webkit-filter: hue-rotate(0deg);
  }
}

@keyframes filter-animation {
  0% {
    filter: hue-rotate(0deg);
  }

  50% {
    filter: hue-rotate(360deg);
  }

  100% {
    filter: hue-rotate(0deg);
  }
}


.iframe {
    height: 100%;
    width: 100%;
}

.wrapper {
    width: 100%;
    height: 100%;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-transition: margin-left .3s ease,margin-left .3s ease;
    transition: margin-left .3s ease,margin-left .3s ease
}

.wrapper>.sidebar {
    overflow: auto;
    position: relative;
    background: #374153;
    width: 240px;
    padding: 20px 0;
    color: #5f7094;
    z-index: 10;
    box-shadow: inset -1px 0 6px rgba(0,0,0,.2);
}

.wrapper>.sidebar .avatar {
    text-align: center
}

.wrapper>.sidebar .avatar img {
    display: block;
    margin: 0 auto 10px;
}

.wrapper>.sidebar .avatar .ui.dropdown {
    margin-bottom: 4px
}

.wrapper>.sidebar .avatar .ui.dropdown>.text {
    font-size: 16px;
    line-height: 32px;
    color: #eee;
    opacity: 1
}

.wrapper>.sidebar .avatar .ui.dropdown>.icon {
    margin-left: 2px
}

.wrapper>.sidebar .group {
    padding: 20px
}

.wrapper>.sidebar .group .title {
    color: #67758e;
    font-weight: 700
}

.wrapper>.sidebar .group ul {
    padding: 0;
    margin: 0;
    list-style: none
}

.wrapper>.sidebar .group li {
    padding: 10px 20px 10px 48px;
    border-left: 4px solid transparent;
    margin: 0 -20px;
    color: #a1acc0;
    cursor: pointer;
    box-sizing: border-box;
    -webkit-transition: background .2s,color .2s;
    transition: background .2s,color .2s;
    position: relative
}

.wrapper>.sidebar .group li .icon {
    position: absolute;
    left: 20px;
    font-size: 18px
}

.wrapper>.sidebar .group li.active,.wrapper>.sidebar .group li:hover {
    background: #313a4a;
    color: #fff
}

.wrapper>.sidebar .group li.active {
    border-color: #3fa5fd
}

.wrapper>.sidebar hr {
    display: block;
    height: 4px;
    background: #303949;
    border: 0;
    border-bottom: 1px solid #3e485c
}

.wrapper>.notification-panel {
    margin-right: -280px;
    background: #374153;
    width: 280px;
    padding: 20px 0;
    color: #a1abc0;
    z-index: 10;
    box-shadow: inset -1px 0 6px rgba(0,0,0,.2);
    -webkit-transition: margin-right .3s ease;
    transition: margin-right .3s ease
}

.wrapper>.notification-panel h3 {
    padding: 0 25px;
    color: #eee;
    font-weight: 400
}

.wrapper.show-notification {
    margin-left: -280px
}

.wrapper>.main-content {
    -webkit-box-flex: 1;
    -ms-flex: 1;
    flex: 1;
    overflow-y: auto;
    -webkit-transition: margin-right .3s ease;
    transition: margin-right .3s ease;
    position: relative
}

.wrapper>.main-content>.scroll-container {
    position: absolute;
    left: 0;
    right: 0;
    top: 72px;
    bottom: 0;
    padding-bottom: 32px
}

.wrapper>.main-content>.scroll-container>* {
    margin: 24px 24px 0
}

.wrapper>.main-content>.scroll-container>#loader,.wrapper>.main-content>.scroll-container>.ps-scrollbar-x-rail,.wrapper>.main-content>.scroll-container>.ps-scrollbar-y-rail {
    margin: 0
}

.wrapper>.main-content>.header {
    position: relative;
    height: 72px;
    line-height: 72px;
    margin: 0;
    background: #fff;
    box-shadow: 0 1px 4px 2px #e5e7ea;
    overflow: hidden;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    z-index: 10
}

.wrapper>.main-content>.header h1 {
    height: 72px;
    line-height: 72px;
    display: inline-block;
    padding: 0 24px;
    margin: 0;
    font-weight: 400;
    font-size: 22px;
    -webkit-box-flex: 1;
    -ms-flex: 1;
    flex: 1
}

.wrapper>.main-content>.header button {
    width: 72px;
    border: 0 solid transparent;
    border-left: 1px solid #e5e7ea;
    border-right: 1px solid #e5e7ea;
    padding: 0;
    margin: 0 0 0 -1px;
    background: #fff;
    font-size: 20px;
    outline: none;
    -webkit-transition: background .3s ease,color .3s ease;
    transition: background .3s ease,color .3s ease
}

.wrapper>.main-content>.header button:active,.wrapper>.main-content>.header button:hover {
    background: #2185d0;
    color: #fff
}

.wrapper>.main-content>.scroll-container>.card {
    position: relative;
    background: #fff;
    padding: 24px;
    border-radius: 4px;
    box-shadow: 0 0 4px 2px #e5e7ea
}

.wrapper>.main-content>.scroll-container>.card.qrcode {
    text-align: center
}

.wrapper>.main-content>.scroll-container>.card.qrcode img {
    margin: 0 auto
}

#sign-log .time {
    width: 150px
}

#sign-log tfoot tr {
    box-shadow: none!important
}

#toggle-sidebar,.hidden {
    display: none
}

.clearfix:after {
    visibility: hidden;
    display: block;
    content: "";
    clear: both;
    height: 0
}

.ihide {
    display: none !important;
}

`],{type: 'text/css'});
    var bcss = document.createElement('link');
    bcss.rel='stylesheet';
    bcss.type='text/css';
    bcss.href=URL.createObjectURL(blob);
    document.head.append(bcss);
    var fa = document.createElement('link');
    fa.rel='stylesheet';
    fa.type='text/css';
    fa.href='https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css';
    document.head.append(fa);
    var semantic_css = document.createElement('link');
    semantic_css.rel='stylesheet';
    semantic_css.type='text/css';
    semantic_css.href='https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.2.13/semantic.min.css';
    document.head.append(semantic_css);
    var normal_css = document.createElement('link');
    normal_css.href='https://cdnjs.cloudflare.com/ajax/libs/normalize/7.0.0/normalize.min.css';
    normal_css.rel='stylesheet';
    normal_css.type='text/css';
    document.head.append(normal_css);
    var semantic_js = document.createElement('script');
    semantic_js.src='https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.2.13/semantic.min.js';
    document.head.append(semantic_js);
    var swalert = document.createElement('script');
    swalert.src='https://unpkg.com/sweetalert2@7.7.0/dist/sweetalert2.all.js';
    document.head.append(swalert);
})();