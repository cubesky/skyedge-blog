// ==UserScript==
// @name         阿米巴周报灵感
// @version      0.1
// @description  我的天，给我一点有毒的灵感吧！
// @author       CubeSky
// @match        http://amiba.icesimba.com:8200/client/weeklyreportcommit
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    $('.button_group').append('<button id="givemesoul" style="width: 130px" onclick="givemesoul()">给我一点灵感</button>');
    window.givemesoul = function() {
        parent.swal({
            title: '正在获取灵感',
            type: 'info',
            onOpen: () => { parent.swal.showLoading(); }
        });
        $.ajax({
            url: 'https://soulposion.utilapi.bid/text',
            success: function(text) {
                parent.swal.hideLoading();
                parent.swal({
                    title: text,
                    type: 'success',
                    text: '哦，我的老天，看看这些优秀的灵感！',
                    width: '80%'
                });
            },
            error: function(err) {
                parent.swal({
                    title: '灵感？',
                    type: 'error',
                    html: '哦，我的老天，我居然一点灵感都没有。<br>也许，我们可以先去买些橘子，我的老伙计！'
                });
            }
        });
    };
})();