// ==UserScript==
// @name         阿米巴时间管理任务提交模态修改
// @version      0.1
// @description  修复模态输入
// @author       CubeSky
// @match        http://amiba.icesimba.com:8200/client/commitinfo
// @match        http://amiba.icesimba.com:8200/client/supplementinfo
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    $('#add_task_button').off('click');
    $('#modify_task_button').off('click');
    $('#add_task_button').on('click',function(){
        window.swal({
            html: $('#tempaddtask').html().split('id="').join('id="s').split('id="smodify_temp_task_button"').join('id="smodify_temp_task_button" style="display:none"').split('id="scancel_temp_task_button"').join('id="scancel_temp_task_button" style="display:none"'),
            showCancelButton:true,
            showConfirmButton: true,
            allowOutsideClick: false,
            allowEscapeKey: false,
            allowEnterKey: false,
            showLoaderOnConfirm: true,
            width: '80%',
            onOpen: () => {
                $("#smodify_temp_task_button").val("create");
                $("#smodify_temp_task_button").text("添加");
            },
            preConfirm: () => {
                return new Promise((resolve, reject) => {
                    window.addTaskDialogOK(resolve, reject);
                });
            }
        }).then(function(result){ if(result.value){ window.swal('添加成功','完成','success'); } },function(er){ window.swal(er,'失败','error'); });
    });
    $('#modify_task_button').on('click',function(){
        window.swal({
            html: $('#tempaddtask').html().split('id="').join('id="s').split('id="smodify_temp_task_button"').join('id="smodify_temp_task_button" style="display:none"').split('id="scancel_temp_task_button"').join('id="scancel_temp_task_button" style="display:none"'),
            showCancelButton: true,
            showConfirmButton: true,
            allowOutsideClick: false,
            allowEscapeKey: false,
            allowEnterKey: false,
            showLoaderOnConfirm: true,
            width: '80%',
            onOpen : ()=>{
                var taskid = $("#commitinfotaskname").val();
                $("#smodify_temp_task_button").val("modify");
                $.ajax({
                    url: "http://" + window.location.host + "/task/getsingletask",
                    type: 'post',
                    data: {
                        task_id: taskid,
                    },
                })
                    .done(function(data) {
                    if (data.code === "0") {
                        $("#stask_name").val(data.obj.result.task_name);
                        $("#sproject_id").val(data.obj.result.project_id);
                        $("#sexpected_start_time").val(data.obj.result.expected_start_time);
                        $("#sexpected_completion_time").val(data.obj.result.expected_completion_time);
                        $("#stask_demand_side").val(data.obj.result.task_demand_side);
                        $("#screate_task_type_select").val(data.obj.result.task_type);
                        $("#stask_partner").val(data.obj.result.task_partner);
                        $("#stask_executor").val(data.obj.result.task_executor);
                        $("#stask_description").val(data.obj.result.task_description);
                        $("#stask_remarks").val(data.obj.result.task_remarks);
                        $("#stask_id").val(data.obj.result.id);
                        $("#stask_status").val(data.obj.result.task_status);
                    } else {
                        showDialog("#register_floatwindow", "获取失败", data.msg, "failed");
                    }
                })
                    .fail(function(data) {
                    console.log(data);
                })
                    .always(function() {
                    console.log("complete");
                });
            },preConfirm: () => {
                return new Promise((resolve, reject) => {
                    window.addTaskDialogOK(resolve, reject);
                });
            }
        }).then(function(result){ if(result.value){ window.swal('添加成功','完成','success'); } },function(er){ window.swal(er,'失败','error'); });
    });
    window.addTaskDialogOK = function(resolve, reject) {
        $("#suser_name").val(username);
        if ($("#screate_task_type_select").val == "normal") {
            var start_time = $("#sexpected_start_time").val();
            var completion_time = $("#sexpected_completion_time").val();
            var d1 = new Date(start_time.replace(/\-/g, '/'));
            var d2 = new Date(completion_time.replace(/\-/g, '/'));
            if (d2 < d1) {
                reject("预期结束时间小于预期开始时间");
                return false;
            }
        }
        if ($('#smodify_temp_task_button').val() === "modify") {
            $.ajax({
                url: "http://" + window.location.host + "/task/modifytask",
                type: 'post',
                async: false,
                data: GetFormData($("#smodify_task").serializeArray()),
            })
                .done(function(data) {
                if (data.code == "0") {
                    var projectid = $("#sproject_id").val();
                    GetTask(projectid);
                    resolve();
                } else {
                    reject(data.msg);
                }

            })
                .fail(function(data) {
                reject(data.msg);
            })
                .always(function() {
                console.log("complete");
            });

        } else {
            $.ajax({
                url: "http://" + window.location.host + "/task/createtask",
                type: 'post',
                async: false,
                data: GetFormData($("#smodify_task").serializeArray()),
            })
                .done(function(data) {
                if (data.code == "0") {
                    var projectid = $("#sproject_id").val();
                    GetTask(projectid);
                    resolve();
                } else {
                    reject(data.msg);
                }

            })
                .fail(function(data) {
                reject(data.msg);
            })
                .always(function() {
                console.log("complete");
            });
        }
    };
})();