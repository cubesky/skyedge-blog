// ==UserScript==
// @name         阿米巴滚动条修正
// @version      0.1
// @description  修正阿米巴滚动条
// @author       CubeSky
// @match        http://amiba.icesimba.com:8200/client/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    if (window.location.href === 'http://amiba.icesimba.com:8200/client/index' || window.location.href === 'http://amiba.icesimba.com:8200/client/index#') {
        $('body').css('overflow','hide');
    }else{
        $('body').css('overflow-x','auto');
    }
})();