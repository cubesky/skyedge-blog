// ==UserScript==
// @name         阿米巴登录页修复
// @version      0.1
// @description  修复阿米巴登录页
// @author       You
// @match        http://amiba.icesimba.com:8200/client/login
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    var newIndex=`
<style>
    body {
      background-image: url("../img/amibalogin/background.png");
      background-size:cover;
    }
    body > .grid {
      height: 100%;
    }
    .image {
      margin-top: -100px;
    }
    .column {
      max-width: 450px;
    }
</style>
<div class="ui middle aligned center aligned grid">
  <div class="column">
    <h2 class="ui teal header">
      <div class="content">
        登录到阿米巴
      </div>
    </h2>
    <div class="ui large form">
      <div class="ui stacked segment">
        <div class="field">
          <div class="ui left icon input">
            <i class="user icon"></i>
            <input type="text" id="login_user_name" placeholder="用户名" ">
          </div>
        </div>
        <div class="field">
          <div class="ui left icon input">
            <i class="lock icon"></i>
            <input type="password" id="login_password" placeholder="密码">
          </div>
        </div>
        <div class="ui fluid large teal submit button" id="login_btn_fix">登录</div>
      </div>

      <div class="ui error message"></div>

    </div>
  </div>
</div>
`;
    $('body').html(newIndex);
    window.alert = function(data) {
        swal({
            text: data,
            title:'错误',
            type:'error',
            timer: 2500
        });
    };
    $('#login_btn_fix').on("click", function() {
        if ($("#login_user_name").val() === "" || $("#login_user_name").val() === "") {
            alert("用户名或密码不能为空");
        } else {
            var postdata = {
                "user_name": $("#login_user_name").val(),
                "password": $("#login_password").val(),
            };
            $.ajax({
                type: 'POST',
                url: "http://" +window.location.host+"/userinfo/login",
                data: postdata,
                success: function(message) {
                    if (message.code == "0") {
                        var cookiedata = {
                            "user_name": $("#login_user_name").val(),
                            "password": $("#login_password").val(),
                            "permission": message.obj.result.UserPermission,
                        };
                        var jsoncookiedata = JSON.stringify(cookiedata);
                        $.cookie('amibaCookie', jsoncookiedata, {
                            expires: 30,
                            path: "/"
                        });
                        location.href = "http://" +window.location.host+"/client/index";
                    } else {
                        $.cookie('amibaCookie', null, {
                            expires: -1,
                            path: "/"
                        });
                        showDialog("", "登录失败", message.msg, "failed");
                    }
                },
                error: function(data) {
                    $.cookie('amibaCookie', null);
                    showDialog("", "登录失败", message.msg, "failed");
                }
            });
        }
    });
    window.keyLogin = function() {
        if (event.keyCode == 13) {
            document.getElementById("login_btn_fix").click();
        }
    };
})();