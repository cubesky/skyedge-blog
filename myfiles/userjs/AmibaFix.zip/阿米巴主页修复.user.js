// ==UserScript==
// @name         阿米巴主页修复
// @version      0.1
// @description  完全重写阿米巴主页
// @author       CubeSky
// @match        http://amiba.icesimba.com:8200/client/index
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    $('body')[0].style='';
    $('.page-content').remove();
    var reqHoli = new Blob([`
<html>
<head>
<meta charset="utf-8"/>
<title>请假中心</title>
<script src="https://unpkg.com/sweetalert2@7.7.0/dist/sweetalert2.all.js"></script>
<script src="https://unpkg.com/ef.js@latest"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.2.13/semantic.min.css" rel="stylesheet" type="text/css">
<style>
.wrapper {
width: 100%;
height: 100%;
padding: 15px;
}
.txar { white-space: pre; }
</style>
</head>
<body>
<div class="wrapper">
<div class="ui raised segment">
<div class="ui"><h2>请假中心 <small>由 CubeSky 全局补丁 强力驱动</small></h2></div>
<div class="ui divider"></div>
<form class="ui form" action="#" onsubmit="return false;">
<div class="field">
<label>该邮件将发送至</label>

<select name="emailto" class="ui fluid dropdown">
<option value="" selected disabled hidden>选择部门</option>
<option value="hong.yang@icesimba.com,jsgao1204@icesimba.com,yangqin.liao@icesimba.com,yanjun.zhang@icesimba.com,yanqiang.wei@icesimba.com">产品技术部</option>
</select>


</div>
<div class="field">
<label>请假原因</label>
<input type="text" name="hdreason" placeholder="请假原因">
</div>
<div class="field">
<label>请假日期（一行一个）<button class="ui basic button" onclick="addTemplate()"><i class="icon plus"></i>添加模板 [<span id="ntemp"></span>]</button></label>
<textarea type="text" name="hdate" placeholder="请假日期"></textarea>
</div>
<button class="ui positive fluid button" onclick="sendonmail()">激活邮件客户端</button>
</form>
<div class="ui divider"></div>
<div class="ui message">
<div class="header">
邮件预览
</div>
<br>
<div id="emailpreview">
</div>
</div>
</div>
</div>
<script>
var myName = '{MyName}';
var emailTemplate = \`
HI ALL:<br>
- - -<br>
申请人：{MyNameMod}<br>
- - -<br>
在以下时间需要请假<br>
{MyHoliday}<br>
<br>
- - -<br>
请假原因：<br>
{MyDetailReason}<br>
- - -<br>
状态： 申请<br>
\`.replace('{MyNameMod}',myName);
var efemail = new ef.t\`
>div.txar
  .HI ALL:
  >br
  .- - -
  >br
  .申请人：{{name}}
  >br
  .- - -
  >br
  .在以下时间需要请假
  >br
  .{{holiday}}
  >br
  .- - -
  >br
  .请假原因：
  >br
  .{{reason}}
  >br
  .- - -
  >br
  .状态： 申请
  >br
\`;
efemail.$mount({target: document.getElementById('emailpreview')});
efemail.$data.name = myName;
document.getElementsByName('hdreason')[0].addEventListener('input',function(){ efemail.$data.reason = document.getElementsByName('hdreason')[0].value });
document.getElementsByName('hdate')[0].addEventListener('input',function(){ efemail.$data.holiday = document.getElementsByName('hdate')[0].value; });

function sendonmail(){
window.location.href = 'mailto:{mto}?subject={subject}&body={body}'.replace('{subject}','请假申请 ' + myName).replace('{body}',efemail.$element.innerHTML.replace(/\\n/g,'%0a').replace(/<br>/g,'%0a')).replace('{mto}',document.getElementsByName('emailto')[0].value);
}

function addTemplate() {
document.getElementsByName('hdate')[0].value = (document.getElementsByName('hdate')[0].value + '\\n' + (new Date()).getFullYear() + ' 年 ' + addZero('' + ((new Date()).getMonth() + 1)) + ' 月  日').trim();
efemail.$data.holiday = document.getElementsByName('hdate')[0].value;
}

function addZero(str){
str ='0'+str;
return str.substring(str.length-2,str.length);
}

document.getElementById('ntemp').innerText = (new Date()).getFullYear() + ' 年 ' + addZero('' + ((new Date()).getMonth() + 1)) + ' 月  日'

</script>
</body>
</html>
`.replace('{MyName}',JSON.parse($.cookie().amibaCookie).user_name).replace('{MyNameSubject}',JSON.parse($.cookie().amibaCookie).user_name)], {type : 'text/html'});
    var reqHoliUrl = URL.createObjectURL(reqHoli);
    var newIndex = `
<div class="wrapper" id="uload" style="display:none">
<div class="sidebar">
<button class="ui button basic fluid sidebtn" onclick="sbhide()" id="sbtn_s" style="margin-top: -20px;margin-bottom: 20px;"><i class="list layout icon"></i> 隐藏侧边栏</button>
<div class="avatar">
<div class="gray-img-b"><img class="gray-img" src="../img/amibaindex/left/logo.png"></div>
<div class="ui dropdown" tabindex=0 id="user-actions">
<div class="text">阿米巴系统<br>非官方补丁版<br><small>由 CubeSky 强力驱动</small></div>
<hr>
<div class="text">用户：<span class="text" id="whologin"></span></div>
</div>
</div>
<hr>
<div class="group">
<p class="title"><i class="fa fa-clock-o"></i>  时间管理</p>
<ul>
<li onclick="loadInIframe('./commitinfo')"><i class="fa fa-gear"></i>  提交信息 </li>
<li onclick="loadInIframe('./supplementinfo')"><i class="fa fa-code-fork"></i>  补填信息 </li>
</ul>
<p class="title"><i class="fa fa-pie-chart"></i>  数据统计</p>
<ul>
<li onclick="loadInIframe('./statisticpersonal')"><i class="fa fa-bar-chart"></i>  个人统计 </li>
<li onclick="loadInIframe('./statisticproject')" style="display:none" class="p_all p_projectli"><i class="fa fa-bar-chart"></i>  项目统计 </li>
<li onclick="loadInIframe('./statisticdepartment')" style="display:none" class="p_all p_departmentli"><i class="fa fa-bar-chart"></i>  部门统计 </li>
</ul>
<p style="display:none;" class="title p_all p_managementmenu"><i class="fa fa-cogs"></i>  后台管理</p>
<ul>
<li onclick="loadInIframe('./managementpersonal')" style="display:none" class="p_all p_personalmanageli"><i class="fa fa-user-circle"></i>  同狮管理 </li>
<li onclick="loadInIframe('./managementproject')" style="display:none" class="p_all p_projectmanageli"><i class="fa fa-envelope"></i>  项目管理 </li>
<li onclick="loadInIframe('./managementdepartment')" style="display:none" class="p_all p_departmentmanageli"><i class="fa fa-th-large"></i>  部门管理 </li>
</ul>
<p style="display:none;" class="title p_all p_costmenu"><i class="fa fa-btc"></i>  成本核算</p>
<ul>
<li onclick="loadInIframe('./costsetperson')" style="display:none" class="p_all p_setcostli"><i class="fa fa-pie-chart"></i>  设置成本 </li>
<li onclick="loadInIframe('./costtotal')" style="display:none" class="p_all p_getdorpcostli"><i class="fa fa-line-chart"></i>  总体成本 </li>
<li onclick="loadInIframe('./costpersons')" style="display:none" class="p_all p_personcostli"><i class="fa fa-area-chart"></i>  人员成本 </li>
</ul>
<p class="title"><i class="fa fa-tasks"></i>  任务系统</p>
<ul>
<li onclick="loadInIframe('./taskcreate')"><i class="fa fa-plus"></i>  新建任务 </li>
<li onclick="loadInIframe('./taskmanagement')"><i class="fa fa-archive"></i>  管理任务 </li>
</ul>
<p class="title"><i class="fa fa-file-o"></i>  周报系统</p>
<ul>
<li onclick="loadInIframe('./weeklyreportcommit')"><i class="fa fa-file-text"></i>  生成周报 </li>
<li onclick="loadInIframe('./weeklyreportview')"><i class="fa fa-file"></i>  查看周报 </li>
<li onclick="loadInIframe('./weeklyreportscore')" id="scorereport" style="display:none" class="p_all p_scorereport"><i class="fa fa-file-text-o"></i>  评价周报 </li>
</ul>
<p class="title"><i class="fa fa-address-card"></i>  个人管理</p>
<ul>
<li onclick="loadInIframe('{reqHoli}')"><i class="fa fa-calendar-minus-o"></i>  请假 [补丁专属] </li>
<li onclick="exitClickPro()"><i class="fa fa-sign-out"></i>  退出 </li>
</ul>
</div>
</div>
<div class="main-content" style="overflow: hidden;">
<button class="ui button basic fluid sidebtn" onclick="sbshow()" id="sbin_o"><i class="list layout icon"></i> 显示侧边栏</button>
<div class="ui active dimmer" id="loaderIcon">
<div class="ui text loader">加载中</div>
</div>
<iframe id="ifra" class="iframe" frameborder="no" src="./commitinfo" onload="finishIframe()"></iframe>
</div>
</div>
`.replace('{reqHoli}',reqHoliUrl);
    window.finishIframe=function(){
        $('#loaderIcon').removeClass('active');
    };
    $('body').prepend(newIndex);
    $('#whologin').text(JSON.parse($.cookie().amibaCookie).user_name);
var permission = $.parseJSON($.cookie('amibaCookie')).permission;
if (permission & Math.pow(2, 6) || $.parseJSON($.cookie('amibaCookie')).user_name == "魏衍强") { // 6-管理员
    $(".p_all").css('display', '');
} else {
    if (permission & Math.pow(2, 1) || permission & Math.pow(2, 3)) { // 1-项目负责人 3-发行
        $('.p_projectli').css('display', '');
        $(".p_costmenu").css('display', '');
        $(".p_getdorpcostli").css('display', '');
    }
    if (permission & Math.pow(2, 2)) { // 2-部门负责人
        $('.p_departmentli').css('display', '');
        $(".p_costmenu").css('display', '');
        $(".p_getdorpcostli").css('display', '');
        $(".p_scorereport").css('display', '');
    }
    if (permission & Math.pow(2, 4) || permission & Math.pow(2, 5)) { // 4-财务（管理员工，部门） 5-财务（管理项目，员工成本）
        $(".p_costmenu").css('display', '');
        $(".p_getdorpcostli").css('display', '');
        $(".p_managementmenu").css('display', '');
        if (permission & Math.pow(2, 4)) {
            $(".p_personalmanageli").css('display', '');
            $(".p_departmentmanageli").css('display', '');
        } else if (permission & Math.pow(2, 5)) {
            $(".p_projectmanageli").css('display', '');
            $(".p_costmenu").css('display', '');
            $(".p_setcostli").css('display', '');
            $(".p_personcostli").css('display', '');
        }
    }
}
    document.getElementById('ifra').src = './commitinfo';
    window.showDialogSwal = function(id,title,text,result) {
        var icons;
        if(result == "failed") {
            icons = 'error';
        } else {
            icons = 'success';
        }
        if(text === 'success') {
            text = '阿米巴太难用了';
        }
        swal({
            type: icons,
            title: title,
            text: text,
            showConfirmButton: false,
            timer: 2500
        });
    };
    window.loadInIframe = function(url) {
        $('#loaderIcon').addClass('active');
        $('#ifra').attr('src',url);
    };
    window.exitClickPro = function () {
        swal({
            title: '你确定要退出嘛',
            type: 'warning',
            showCancelButton: true,
            confirmButtonText: '退出',
            cancelButtonText: '取消',
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            focusCancel: true
        }).then((result) => {
            if (result.value) {
                rowClick();
            }
        });
    };
    window.onresize = function () {
        if($(window).width() < 767) {
            $('.sidebar').hide();
            $('.sidebtn').show();
        } else {
            $('.sidebar').show();
            $('.sidebtn').hide();
        }
    };
    window.sbhide = function() {
        $('.sidebar').hide();
    };
    window.sbshow = function() {
        $('.sidebar').show();
    };
    window.onresize();
})();