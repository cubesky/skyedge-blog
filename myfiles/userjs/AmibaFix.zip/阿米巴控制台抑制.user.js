// ==UserScript==
// @name         阿米巴控制台抑制
// @version      0.1
// @description  抑制阿米巴控制台输出
// @author       CubeSky
// @match        http://amiba.icesimba.com:8200/client/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    var consoleHolder = console;
    window.debug = function(bool){
        if(!bool){
            consoleHolder = window.console;
            window.console = {};
            Object.keys(consoleHolder).forEach(function(key){
                window.console[key] = function(){};
            });
        }else{
            window.console = consoleHolder;
        }
    };
    debug(false);
    consoleHolder.clear();
    consoleHolder.log('\n %c 阿米巴修复 | Version: 42.0 | 终于能用了 %c \n', 'color:#455a64;background:#e0e0e0;padding:10px 0;margin-bottom: 10px;border-top-left-radius:5px;border-bottom-left-radius:5px;', 'color:#455a64;background:#e0e0e0;padding:10px 0;margin-bottom: 10px;border-top-right-radius:5px;border-bottom-right-radius:5px;');
    window._console = consoleHolder;
})();