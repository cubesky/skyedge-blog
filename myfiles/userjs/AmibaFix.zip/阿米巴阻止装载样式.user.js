// ==UserScript==
// @name         阿米巴阻止装载样式
// @version      0.1
// @description  阻止阿米巴装载垃圾样式
// @author       CubeSky
// @match        http://amiba.icesimba.com:8200/client/index
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    $('link').remove();
    $('style').remove();
    document.body.innerHTML = document.body.innerHTML.replace('--&gt;','');
})();