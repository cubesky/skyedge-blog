// ==UserScript==
// @name         阿米巴全局修复
// @version      0.1
// @description  修复阿米巴的一些小问题
// @author       CubeSky
// @match        http://amiba.icesimba.com:8200/client/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    $('.nav').remove();
    console.log('阿米巴修复脚本已应用');
    if (window.location.href==='http://amiba.icesimba.com:8200/client/commitinfo' || window.location.href==='http://amiba.icesimba.com:8200/client/supplementinfo') {
       $('.commitwindow').css('width','');
    }
    if (window.location.href === 'http://amiba.icesimba.com:8200/client/statisticpersonal') {
      $('img').remove();
    }
})();